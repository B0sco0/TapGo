﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

class TicketData
{
    public string Nome { get; set; } = "";
    public string Cognome { get; set; } = "";
    public string CodiceFiscale { get; set; } = "";
    public string Linea { get; set; } = "";
    public string TipoBiglietto { get; set; } = "";
    public string Destinazione { get; set; } = "";
    public DateTime Scadenza { get; set; }
}

class TapAndGoServer
{
    private static readonly Dictionary<string, TicketData> tickets = new Dictionary<string, TicketData>();
    private const string PrinterIp = "192.168.1.33";
    private const int PrinterPort = 9100;

    static async Task Main(string[] args)
    {
        int port = 8888;
        TcpListener server = new TcpListener(IPAddress.Any, port);
        server.Start();

        Console.WriteLine($"[SERVER] Avviato con successo sulla porta {port}.");
        Console.WriteLine($"[SERVER] Stampante fisica configurata su {PrinterIp}:{PrinterPort}");
        Console.WriteLine("[SERVER] In attesa di utenti e controllori...\n");

        try
        {
            while (true)
            {
                TcpClient client = await server.AcceptTcpClientAsync();
                _ = HandleClientAsync(client);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[ERRORE SERVER] {ex.Message}");
        }
    }

    private static async Task HandleClientAsync(TcpClient client)
    {
        string clientId = client.Client.RemoteEndPoint?.ToString() ?? "Sconosciuto";

        try
        {
            using (NetworkStream stream = client.GetStream())
            using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
            using (StreamWriter writer = new StreamWriter(stream, Encoding.UTF8) { AutoFlush = true })
            {
                string? mode = await reader.ReadLineAsync();

                if (mode == "USER")
                {
                    string? nome = await reader.ReadLineAsync();
                    string? cognome = await reader.ReadLineAsync();
                    string? cf = await reader.ReadLineAsync();
                    string? linea = await reader.ReadLineAsync();
                    string? tipo = await reader.ReadLineAsync();
                    string? dest = await reader.ReadLineAsync();

                    int durataMinuti = tipo?.ToLower().Contains("giornaliero") == true ? 1440 : 90;
                    DateTime scadenza = DateTime.Now.AddMinutes(durataMinuti);
                    string codiceUnivoco = "TICK-" + Guid.NewGuid().ToString().Substring(0, 6).ToUpper();

                    var nuovoBiglietto = new TicketData
                    {
                        Nome = nome ?? "",
                        Cognome = cognome ?? "",
                        CodiceFiscale = cf ?? "",
                        Linea = linea ?? "",
                        TipoBiglietto = tipo ?? "",
                        Destinazione = dest ?? "",
                        Scadenza = scadenza
                    };

                    lock (tickets)
                    {
                        tickets[codiceUnivoco] = nuovoBiglietto;
                    }

                    Console.WriteLine($"[EMISSIONE] Creato biglietto {codiceUnivoco} per {nuovoBiglietto.Nome} {nuovoBiglietto.Cognome} (Linea: {nuovoBiglietto.Linea})");

                    // Risponde al client
                    await writer.WriteLineAsync(codiceUnivoco);
                    await writer.WriteLineAsync(scadenza.ToString("dd/MM/yyyy HH:mm"));

                    // Stampa il biglietto fisico in modo asincrono senza bloccare il client
                    _ = PrintTicketAsync(codiceUnivoco, nuovoBiglietto);
                }
                else if (mode == "INSPECTOR")
                {
                    string? pwd = await reader.ReadLineAsync();

                    if (pwd != "1234")
                    {
                        await writer.WriteLineAsync("AUTH_FAIL");
                        Console.WriteLine($"[SICUREZZA] Tentativo di accesso controllore fallito da {clientId} (Password errata)");
                        return;
                    }

                    await writer.WriteLineAsync("AUTH_OK");
                    Console.WriteLine($"[ACCESSO] Controllore autenticato con successo da {clientId}");

                    string? codiceDaVerificare;
                    while ((codiceDaVerificare = await reader.ReadLineAsync()) != null)
                    {
                        codiceDaVerificare = codiceDaVerificare.Trim();

                        TicketData? t = null;
                        lock (tickets)
                        {
                            tickets.TryGetValue(codiceDaVerificare, out t);
                        }

                        if (t != null)
                        {
                            bool ancoraValido = DateTime.Now < t.Scadenza;
                            string statoValidita = ancoraValido ? "VALIDO" : "SCADUTO";

                            await writer.WriteLineAsync("FOUND");
                            await writer.WriteLineAsync(t.Nome);
                            await writer.WriteLineAsync(t.Cognome);
                            await writer.WriteLineAsync(t.CodiceFiscale);
                            await writer.WriteLineAsync(t.Linea);
                            await writer.WriteLineAsync(t.TipoBiglietto);
                            await writer.WriteLineAsync(t.Destinazione);
                            await writer.WriteLineAsync(t.Scadenza.ToString("dd/MM/yyyy HH:mm"));
                            await writer.WriteLineAsync(statoValidita);

                            Console.WriteLine($"[VERIFICA] Biglietto {codiceDaVerificare} controllato: {statoValidita}");
                        }
                        else
                        {
                            await writer.WriteLineAsync("NOT_FOUND");
                            Console.WriteLine($"[VERIFICA] Codice inesistente cercato: {codiceDaVerificare}");
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[ERRORE CLIENT {clientId}] {ex.Message}");
        }
        finally
        {
            client.Close();
        }
    }

    private static async Task PrintTicketAsync(string codice, TicketData data)
    {
        try
        {
            using TcpClient printerClient = new TcpClient();
            using var cts = new System.Threading.CancellationTokenSource(TimeSpan.FromSeconds(5));
            await printerClient.ConnectAsync(PrinterIp, PrinterPort, cts.Token);

            using NetworkStream stream = printerClient.GetStream();

            // Comandi ESC/POS standard: Reset (ESC @), Grassetto ON (ESC E 1), Grassetto OFF (ESC E 0), Taglio parziale (GS V 66 0)
            byte[] escInit = { 0x1B, 0x40 };
            byte[] boldOn = { 0x1B, 0x45, 0x01 };
            byte[] boldOff = { 0x1B, 0x45, 0x00 };
            byte[] cutPaper = { 0x1D, 0x56, 0x42, 0x00 };

            // Codepage 858 (Europa occidentale / italiano) per accenti corretti su stampanti termiche
            Encoding enc = CodePagesEncodingProvider.Instance.GetEncoding(858) ?? Encoding.ASCII;

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("================================");
            sb.AppendLine("        TAP & GO TICKET        ");
            sb.AppendLine("================================");
            sb.AppendLine($"Codice   : {codice}");
            sb.AppendLine($"Nome     : {data.Nome} {data.Cognome}");
            sb.AppendLine($"CF       : {data.CodiceFiscale}");
            sb.AppendLine($"Linea    : {data.Linea}");
            sb.AppendLine($"Tipo     : {data.TipoBiglietto}");
            sb.AppendLine($"Dest.    : {data.Destinazione}");
            sb.AppendLine($"Scadenza : {data.Scadenza:dd/MM/yyyy HH:mm}");
            sb.AppendLine("--------------------------------");
            sb.AppendLine($"Emesso il: {DateTime.Now:dd/MM/yyyy HH:mm}");
            sb.AppendLine("\n\n\n");

            await stream.WriteAsync(escInit);
            await stream.WriteAsync(boldOn);
            await stream.WriteAsync(enc.GetBytes("BIGLIETTO VALIDO\r\n"));
            await stream.WriteAsync(boldOff);
            await stream.WriteAsync(enc.GetBytes(sb.ToString()));
            await stream.WriteAsync(cutPaper);
            await stream.FlushAsync();

            Console.WriteLine($"[STAMPA] Biglietto {codice} inviato a {PrinterIp}:{PrinterPort}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[ERRORE STAMPA {codice}] Impossibile stampare su {PrinterIp}:{PrinterPort} -> {ex.Message}");
        }
    }
}
