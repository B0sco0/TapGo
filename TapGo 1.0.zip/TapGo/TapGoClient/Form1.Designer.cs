﻿namespace TapGoClient
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.TabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lblCodiceRisultato = new System.Windows.Forms.Label();
            this.btnAcquista = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.txtDestinazione = new System.Windows.Forms.TextBox();
            this.txtLinea = new System.Windows.Forms.TextBox();
            this.txtCf = new System.Windows.Forms.TextBox();
            this.txtCognome = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lblEsitoVerifica = new System.Windows.Forms.Label();
            this.btnVerifica = new System.Windows.Forms.Button();
            this.txtCodiceVerifica = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnLoginInspector = new System.Windows.Forms.Button();
            this.txtPassoword = new System.Windows.Forms.TextBox();
            this.labelPassword = new System.Windows.Forms.Label();
            this.TabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // TabControl1
            // 
            this.TabControl1.Controls.Add(this.tabPage1);
            this.TabControl1.Controls.Add(this.tabPage2);
            this.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TabControl1.Location = new System.Drawing.Point(0, 0);
            this.TabControl1.Name = "TabControl1";
            this.TabControl1.SelectedIndex = 0;
            this.TabControl1.Size = new System.Drawing.Size(582, 403);
            this.TabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lblCodiceRisultato);
            this.tabPage1.Controls.Add(this.btnAcquista);
            this.tabPage1.Controls.Add(this.comboBox1);
            this.tabPage1.Controls.Add(this.txtDestinazione);
            this.tabPage1.Controls.Add(this.txtLinea);
            this.tabPage1.Controls.Add(this.txtCf);
            this.tabPage1.Controls.Add(this.txtCognome);
            this.tabPage1.Controls.Add(this.txtNome);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(574, 374);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // lblCodiceRisultato
            // 
            this.lblCodiceRisultato.AutoSize = true;
            this.lblCodiceRisultato.Location = new System.Drawing.Point(399, 318);
            this.lblCodiceRisultato.Name = "lblCodiceRisultato";
            this.lblCodiceRisultato.Size = new System.Drawing.Size(0, 16);
            this.lblCodiceRisultato.TabIndex = 13;
            // 
            // btnAcquista
            // 
            this.btnAcquista.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAcquista.Location = new System.Drawing.Point(258, 202);
            this.btnAcquista.Name = "btnAcquista";
            this.btnAcquista.Size = new System.Drawing.Size(114, 40);
            this.btnAcquista.TabIndex = 12;
            this.btnAcquista.Text = "Acquista";
            this.btnAcquista.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "90 Minuti",
            "Giornaliero",
            "1 Minuto"});
            this.comboBox1.Location = new System.Drawing.Point(258, 144);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 24);
            this.comboBox1.TabIndex = 11;
            // 
            // txtDestinazione
            // 
            this.txtDestinazione.Location = new System.Drawing.Point(258, 54);
            this.txtDestinazione.Name = "txtDestinazione";
            this.txtDestinazione.Size = new System.Drawing.Size(100, 22);
            this.txtDestinazione.TabIndex = 10;
            // 
            // txtLinea
            // 
            this.txtLinea.Location = new System.Drawing.Point(8, 281);
            this.txtLinea.Name = "txtLinea";
            this.txtLinea.Size = new System.Drawing.Size(100, 22);
            this.txtLinea.TabIndex = 9;
            // 
            // txtCf
            // 
            this.txtCf.Location = new System.Drawing.Point(7, 202);
            this.txtCf.Name = "txtCf";
            this.txtCf.Size = new System.Drawing.Size(100, 22);
            this.txtCf.TabIndex = 8;
            // 
            // txtCognome
            // 
            this.txtCognome.Location = new System.Drawing.Point(7, 121);
            this.txtCognome.Name = "txtCognome";
            this.txtCognome.Size = new System.Drawing.Size(100, 22);
            this.txtCognome.TabIndex = 7;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(6, 54);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 22);
            this.txtNome.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(253, 14);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(138, 26);
            this.label6.TabIndex = 5;
            this.label6.Text = "Destinazione";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(253, 99);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(158, 26);
            this.label5.TabIndex = 4;
            this.label5.Text = "Durata biglietto";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(7, 236);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 26);
            this.label4.TabIndex = 3;
            this.label4.Text = "Linea";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(155, 26);
            this.label3.TabIndex = 2;
            this.label3.Text = "Codice Fiscale";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(7, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 26);
            this.label2.TabIndex = 1;
            this.label2.Text = "Cognome";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.lblEsitoVerifica);
            this.tabPage2.Controls.Add(this.btnVerifica);
            this.tabPage2.Controls.Add(this.txtCodiceVerifica);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.btnLoginInspector);
            this.tabPage2.Controls.Add(this.txtPassoword);
            this.tabPage2.Controls.Add(this.labelPassword);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(574, 374);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lblEsitoVerifica
            // 
            this.lblEsitoVerifica.AutoSize = true;
            this.lblEsitoVerifica.Location = new System.Drawing.Point(138, 194);
            this.lblEsitoVerifica.Name = "lblEsitoVerifica";
            this.lblEsitoVerifica.Size = new System.Drawing.Size(0, 16);
            this.lblEsitoVerifica.TabIndex = 6;
            // 
            // btnVerifica
            // 
            this.btnVerifica.Location = new System.Drawing.Point(299, 118);
            this.btnVerifica.Name = "btnVerifica";
            this.btnVerifica.Size = new System.Drawing.Size(145, 55);
            this.btnVerifica.TabIndex = 5;
            this.btnVerifica.Text = "verifica";
            this.btnVerifica.UseVisualStyleBackColor = true;
            // 
            // txtCodiceVerifica
            // 
            this.txtCodiceVerifica.Location = new System.Drawing.Point(322, 61);
            this.txtCodiceVerifica.Name = "txtCodiceVerifica";
            this.txtCodiceVerifica.Size = new System.Drawing.Size(100, 22);
            this.txtCodiceVerifica.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(319, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 16);
            this.label7.TabIndex = 3;
            this.label7.Text = "Codice Biglietto";
            // 
            // btnLoginInspector
            // 
            this.btnLoginInspector.Location = new System.Drawing.Point(38, 118);
            this.btnLoginInspector.Name = "btnLoginInspector";
            this.btnLoginInspector.Size = new System.Drawing.Size(134, 55);
            this.btnLoginInspector.TabIndex = 2;
            this.btnLoginInspector.Text = "Login";
            this.btnLoginInspector.UseVisualStyleBackColor = true;
            // 
            // txtPassoword
            // 
            this.txtPassoword.Location = new System.Drawing.Point(38, 62);
            this.txtPassoword.Name = "txtPassoword";
            this.txtPassoword.PasswordChar = '*';
            this.txtPassoword.Size = new System.Drawing.Size(100, 22);
            this.txtPassoword.TabIndex = 1;
            // 
            // labelPassword
            // 
            this.labelPassword.AutoSize = true;
            this.labelPassword.Location = new System.Drawing.Point(56, 29);
            this.labelPassword.Name = "labelPassword";
            this.labelPassword.Size = new System.Drawing.Size(67, 16);
            this.labelPassword.TabIndex = 0;
            this.labelPassword.Text = "Password";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(582, 403);
            this.Controls.Add(this.TabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.TabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl TabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox txtDestinazione;
        private System.Windows.Forms.TextBox txtLinea;
        private System.Windows.Forms.TextBox txtCf;
        private System.Windows.Forms.TextBox txtCognome;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblCodiceRisultato;
        private System.Windows.Forms.Button btnAcquista;
        private System.Windows.Forms.Button btnLoginInspector;
        private System.Windows.Forms.TextBox txtPassoword;
        private System.Windows.Forms.Label labelPassword;
        private System.Windows.Forms.Label lblEsitoVerifica;
        private System.Windows.Forms.Button btnVerifica;
        private System.Windows.Forms.TextBox txtCodiceVerifica;
        private System.Windows.Forms.Label label7;
    }
}

