﻿using System;
using System.Drawing;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TapGoClient
{
    public partial class Form1 : Form
    {
        private const string ServerHost = "127.0.0.1";
        private const int ServerPort = 8888;
        private const int NetworkTimeoutMilliseconds = 5000;

        private TcpClient inspectorClient;
        private StreamReader inspectorReader;
        private StreamWriter inspectorWriter;

        private Panel loginPanel;
        private Panel verificationPanel;
        private TextBox inspectorPasswordTextBox;
        private TextBox ticketCodeTextBox;
        private Label verificationResultLabel;

        public Form1()
        {
            InitializeComponent();
            BuildInterface();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void BuildInterface()
        {
            Text = "Tap & Go - Sistema di biglietteria";
            MinimumSize = new Size(700, 500);
            StartPosition = FormStartPosition.CenterScreen;

            TabControl1.Dock = DockStyle.Fill;
            TabControl1.TabPages.Clear();

            TabPage purchaseTab = new TabPage("1. Area Utente (Acquisto)");
            TabPage inspectorTab = new TabPage("2. Area Controllore");
            TabControl1.TabPages.Add(purchaseTab);
            TabControl1.TabPages.Add(inspectorTab);

            BuildPurchasePanel(purchaseTab);
            BuildInspectorPanel(inspectorTab);
        }

        private void BuildPurchasePanel(TabPage tab)
        {
            TableLayoutPanel layout = CreateLayout(4, 7);
            tab.Controls.Add(layout);

            AddLabel(layout, "Nome", 0, 0);
            TextBox nameTextBox = CreateTextBox();
            layout.Controls.Add(nameTextBox, 1, 0);

            AddLabel(layout, "Cognome", 0, 1);
            TextBox surnameTextBox = CreateTextBox();
            layout.Controls.Add(surnameTextBox, 1, 1);

            AddLabel(layout, "Codice Fiscale", 0, 2);
            TextBox taxCodeTextBox = CreateTextBox();
            taxCodeTextBox.CharacterCasing = CharacterCasing.Upper;
            layout.Controls.Add(taxCodeTextBox, 1, 2);

            AddLabel(layout, "Linea", 0, 3);
            TextBox lineTextBox = CreateTextBox();
            layout.Controls.Add(lineTextBox, 1, 3);

            AddLabel(layout, "Destinazione", 0, 4);
            TextBox destinationTextBox = CreateTextBox();
            layout.Controls.Add(destinationTextBox, 1, 4);

            AddLabel(layout, "Tipo biglietto", 0, 5);
            ComboBox ticketTypeComboBox = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                Dock = DockStyle.Fill
            };
            ticketTypeComboBox.Items.Add("90 minuti");
            ticketTypeComboBox.Items.Add("Giornaliero");
            ticketTypeComboBox.SelectedIndex = 0;
            layout.Controls.Add(ticketTypeComboBox, 1, 5);

            Button purchaseButton = new Button
            {
                Text = "Genera Biglietto",
                AutoSize = true,
                Anchor = AnchorStyles.Left
            };
            layout.Controls.Add(purchaseButton, 1, 6);

            Label purchaseResultLabel = CreateResultLabel();
            layout.Controls.Add(purchaseResultLabel, 2, 0);
            layout.SetRowSpan(purchaseResultLabel, 7);
            layout.SetColumnSpan(purchaseResultLabel, 2);

            purchaseButton.Click += async (sender, e) =>
            {
                await GenerateTicketAsync(
                    nameTextBox,
                    surnameTextBox,
                    taxCodeTextBox,
                    lineTextBox,
                    ticketTypeComboBox,
                    destinationTextBox,
                    purchaseButton,
                    purchaseResultLabel);
            };
        }

        private void BuildInspectorPanel(TabPage tab)
        {
            loginPanel = new Panel { Dock = DockStyle.Fill };
            verificationPanel = new Panel { Dock = DockStyle.Fill, Visible = false };
            tab.Controls.Add(loginPanel);
            tab.Controls.Add(verificationPanel);

            TableLayoutPanel loginLayout = CreateLayout(3, 3);
            loginPanel.Controls.Add(loginLayout);
            AddLabel(loginLayout, "Password controllore", 0, 0);

            inspectorPasswordTextBox = new TextBox
            {
                PasswordChar = '*',
                Dock = DockStyle.Fill
            };
            loginLayout.Controls.Add(inspectorPasswordTextBox, 1, 0);

            Button loginButton = new Button
            {
                Text = "Accedi",
                AutoSize = true,
                Anchor = AnchorStyles.Left
            };
            loginLayout.Controls.Add(loginButton, 1, 1);

            Label loginMessageLabel = CreateResultLabel();
            loginLayout.Controls.Add(loginMessageLabel, 1, 2);
            loginLayout.SetColumnSpan(loginMessageLabel, 2);

            loginButton.Click += async (sender, e) =>
            {
                await LoginInspectorAsync(loginButton, loginMessageLabel);
            };
            inspectorPasswordTextBox.KeyDown += async (sender, e) =>
            {
                if (e.KeyCode == Keys.Enter)
                {
                    e.SuppressKeyPress = true;
                    await LoginInspectorAsync(loginButton, loginMessageLabel);
                }
            };

            TableLayoutPanel verificationLayout = CreateLayout(3, 4);
            verificationPanel.Controls.Add(verificationLayout);
            AddLabel(verificationLayout, "Codice biglietto", 0, 0);

            ticketCodeTextBox = new TextBox
            {
                CharacterCasing = CharacterCasing.Upper,
                Dock = DockStyle.Fill
            };
            verificationLayout.Controls.Add(ticketCodeTextBox, 1, 0);

            Button verifyButton = new Button
            {
                Text = "Verifica",
                AutoSize = true,
                Anchor = AnchorStyles.Left
            };
            verificationLayout.Controls.Add(verifyButton, 1, 1);

            verificationResultLabel = CreateResultLabel();
            verificationResultLabel.Font = new Font("Consolas", 10F);
            verificationResultLabel.AutoSize = false;
            verificationResultLabel.Dock = DockStyle.Fill;
            verificationResultLabel.TextAlign = ContentAlignment.TopLeft;
            verificationLayout.Controls.Add(verificationResultLabel, 0, 2);
            verificationLayout.SetColumnSpan(verificationResultLabel, 3);
            verificationLayout.SetRowSpan(verificationResultLabel, 2);

            verifyButton.Click += async (sender, e) =>
            {
                await VerifyTicketAsync(verifyButton);
            };
            ticketCodeTextBox.KeyDown += async (sender, e) =>
            {
                if (e.KeyCode == Keys.Enter)
                {
                    e.SuppressKeyPress = true;
                    await VerifyTicketAsync(verifyButton);
                }
            };
        }

        private async Task GenerateTicketAsync(
            TextBox nameTextBox,
            TextBox surnameTextBox,
            TextBox taxCodeTextBox,
            TextBox lineTextBox,
            ComboBox ticketTypeComboBox,
            TextBox destinationTextBox,
            Button purchaseButton,
            Label resultLabel)
        {
            string[] values =
            {
                nameTextBox.Text.Trim(),
                surnameTextBox.Text.Trim(),
                taxCodeTextBox.Text.Trim(),
                lineTextBox.Text.Trim(),
                ticketTypeComboBox.Text.Trim(),
                destinationTextBox.Text.Trim()
            };

            if (HasEmptyValue(values))
            {
                resultLabel.ForeColor = Color.Firebrick;
                resultLabel.Text = "Compila tutti i campi prima di generare il biglietto.";
                return;
            }

            SetButtonBusy(purchaseButton, true);
            resultLabel.ForeColor = Color.DarkBlue;
            resultLabel.Text = "Connessione al server...";

            try
            {
                string response;
                using (TcpClient client = await ConnectAsync())
                using (NetworkStream stream = client.GetStream())
                using (StreamReader reader = new StreamReader(stream, Encoding.UTF8, false, 1024, true))
                using (StreamWriter writer = new StreamWriter(stream, new UTF8Encoding(false), 1024, true))
                {
                    writer.AutoFlush = true;
                    await writer.WriteLineAsync("USER");
                    foreach (string value in values)
                    {
                        await writer.WriteLineAsync(value);
                    }

                    string firstLine = await reader.ReadLineAsync();
                    if (firstLine == null)
                    {
                        throw new IOException("Il server ha chiuso la connessione senza restituire il biglietto.");
                    }

                    string secondLine = await reader.ReadLineAsync();
                    response = "CODICE BIGLIETTO: " + firstLine;
                    if (!string.IsNullOrWhiteSpace(secondLine))
                    {
                        response += Environment.NewLine + "SCADENZA: " + secondLine;
                    }
                }

                resultLabel.ForeColor = Color.DarkGreen;
                resultLabel.Text = response;
            }
            catch (Exception ex)
            {
                resultLabel.ForeColor = Color.Firebrick;
                resultLabel.Text = "Errore: " + ex.Message;
            }
            finally
            {
                SetButtonBusy(purchaseButton, false);
            }
        }

        private async Task LoginInspectorAsync(Button loginButton, Label messageLabel)
        {
            string password = inspectorPasswordTextBox.Text.Trim();
            if (password.Length == 0)
            {
                messageLabel.ForeColor = Color.Firebrick;
                messageLabel.Text = "Inserisci la password.";
                return;
            }

            SetButtonBusy(loginButton, true);
            messageLabel.ForeColor = Color.DarkBlue;
            messageLabel.Text = "Autenticazione...";

            try
            {
                CloseInspectorConnection();
                inspectorClient = await ConnectAsync();
                NetworkStream stream = inspectorClient.GetStream();
                inspectorReader = new StreamReader(stream, Encoding.UTF8, false, 1024, true);
                inspectorWriter = new StreamWriter(stream, new UTF8Encoding(false), 1024, true)
                {
                    AutoFlush = true
                };

                await inspectorWriter.WriteLineAsync("INSPECTOR");
                await inspectorWriter.WriteLineAsync(password);
                string response = await inspectorReader.ReadLineAsync();

                if (string.Equals(response, "AUTH_OK", StringComparison.OrdinalIgnoreCase))
                {
                    loginPanel.Visible = false;
                    verificationPanel.Visible = true;
                    ticketCodeTextBox.Focus();
                    messageLabel.Text = string.Empty;
                }
                else
                {
                    CloseInspectorConnection();
                    messageLabel.ForeColor = Color.Firebrick;
                    messageLabel.Text = "Password errata.";
                }
            }
            catch (Exception ex)
            {
                CloseInspectorConnection();
                messageLabel.ForeColor = Color.Firebrick;
                messageLabel.Text = "Errore di connessione: " + ex.Message;
            }
            finally
            {
                SetButtonBusy(loginButton, false);
            }
        }

        private async Task VerifyTicketAsync(Button verifyButton)
        {
            string code = ticketCodeTextBox.Text.Trim();
            if (code.Length == 0)
            {
                verificationResultLabel.ForeColor = Color.Firebrick;
                verificationResultLabel.Text = "Inserisci il codice del biglietto.";
                return;
            }

            if (inspectorWriter == null || inspectorReader == null ||
                inspectorClient == null || !inspectorClient.Connected)
            {
                verificationResultLabel.ForeColor = Color.Firebrick;
                verificationResultLabel.Text = "Sessione controllore non disponibile. Effettua nuovamente l'accesso.";
                loginPanel.Visible = true;
                verificationPanel.Visible = false;
                return;
            }

            SetButtonBusy(verifyButton, true);
            verificationResultLabel.ForeColor = Color.DarkBlue;
            verificationResultLabel.Text = "Verifica in corso...";

            try
            {
                await inspectorWriter.WriteLineAsync(code);
                string header = await inspectorReader.ReadLineAsync();
                if (header == null)
                {
                    throw new IOException("Il server ha chiuso la sessione del controllore.");
                }

                if (string.Equals(header, "NOT_FOUND", StringComparison.OrdinalIgnoreCase))
                {
                    verificationResultLabel.ForeColor = Color.Firebrick;
                    verificationResultLabel.Text = "BIGLIETTO NON TROVATO";
                    return;
                }

                if (!string.Equals(header, "FOUND", StringComparison.OrdinalIgnoreCase))
                {
                    throw new IOException("Risposta non riconosciuta dal server: " + header);
                }

                string nome = await ReadRequiredLineAsync();
                string cognome = await ReadRequiredLineAsync();
                string codiceFiscale = await ReadRequiredLineAsync();
                string linea = await ReadRequiredLineAsync();
                string tipoBiglietto = await ReadRequiredLineAsync();
                string destinazione = await ReadRequiredLineAsync();
                string scadenza = await ReadRequiredLineAsync();
                string stato = await ReadRequiredLineAsync();

                verificationResultLabel.ForeColor =
                    string.Equals(stato, "SCADUTO", StringComparison.OrdinalIgnoreCase)
                        ? Color.Firebrick
                        : Color.DarkGreen;
                verificationResultLabel.Text =
                    "["
                    + stato.ToUpperInvariant()
                    + "]"
                    + Environment.NewLine
                    + "Nome:             "
                    + nome
                    + Environment.NewLine
                    + "Cognome:          "
                    + cognome
                    + Environment.NewLine
                    + "Codice Fiscale:   "
                    + codiceFiscale
                    + Environment.NewLine
                    + "Linea:            "
                    + linea
                    + Environment.NewLine
                    + "Tipo biglietto:   "
                    + tipoBiglietto
                    + Environment.NewLine
                    + "Destinazione:     "
                    + destinazione
                    + Environment.NewLine
                    + "Scadenza:         "
                    + scadenza;
            }
            catch (Exception ex)
            {
                verificationResultLabel.ForeColor = Color.Firebrick;
                verificationResultLabel.Text = "Errore: " + ex.Message;
                CloseInspectorConnection();
            }
            finally
            {
                SetButtonBusy(verifyButton, false);
            }
        }

        private async Task<string> ReadRequiredLineAsync()
        {
            string value = await inspectorReader.ReadLineAsync();
            if (value == null)
            {
                throw new IOException("Il server ha chiuso la sessione durante la verifica.");
            }

            return value;
        }

        private static async Task<TcpClient> ConnectAsync()
        {
            TcpClient client = new TcpClient();
            try
            {
                Task connectTask = client.ConnectAsync(ServerHost, ServerPort);
                if (await Task.WhenAny(connectTask, Task.Delay(NetworkTimeoutMilliseconds)) != connectTask)
                {
                    throw new TimeoutException("Timeout durante la connessione al server.");
                }

                client.ReceiveTimeout = NetworkTimeoutMilliseconds;
                client.SendTimeout = NetworkTimeoutMilliseconds;
                return client;
            }
            catch
            {
                client.Close();
                throw;
            }
        }

        private void CloseInspectorConnection()
        {
            if (inspectorReader != null)
            {
                inspectorReader.Dispose();
                inspectorReader = null;
            }

            if (inspectorWriter != null)
            {
                inspectorWriter.Dispose();
                inspectorWriter = null;
            }

            if (inspectorClient != null)
            {
                inspectorClient.Close();
                inspectorClient = null;
            }
        }

        private static bool HasEmptyValue(string[] values)
        {
            foreach (string value in values)
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    return true;
                }
            }

            return false;
        }

        private static TableLayoutPanel CreateLayout(int columns, int rows)
        {
            TableLayoutPanel layout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(24),
                ColumnCount = columns,
                RowCount = rows,
                AutoScroll = true
            };

            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 150F));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45F));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 55F));

            for (int i = 0; i < rows; i++)
            {
                layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            }

            return layout;
        }

        private static void AddLabel(TableLayoutPanel layout, string text, int column, int row)
        {
            layout.Controls.Add(new Label
            {
                Text = text,
                AutoSize = true,
                Anchor = AnchorStyles.Left,
                Margin = new Padding(3, 8, 3, 8)
            }, column, row);
        }

        private static TextBox CreateTextBox()
        {
            return new TextBox
            {
                Dock = DockStyle.Fill,
                Margin = new Padding(3, 5, 12, 5)
            };
        }

        private static Label CreateResultLabel()
        {
            return new Label
            {
                AutoSize = true,
                MaximumSize = new Size(420, 0),
                Padding = new Padding(12),
                Margin = new Padding(20, 5, 5, 5),
                Text = string.Empty
            };
        }

        private static void SetButtonBusy(Button button, bool busy)
        {
            button.Enabled = !busy;
            Cursor.Current = busy ? Cursors.WaitCursor : Cursors.Default;
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            CloseInspectorConnection();
            base.OnFormClosing(e);
        }
    }
}
